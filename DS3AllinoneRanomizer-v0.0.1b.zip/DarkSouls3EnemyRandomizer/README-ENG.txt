﻿Warning:
*Before you use this Randomizer,please make sure you have DLC1 and DLC2
*This Randomizer cannot be used for Cinder Mod

A comprehensive enemy randomizer for Dark Souls 3,include Bosses and it won't 
affect Side Quests.You may fight Sulyvahn with Knight Onion in Yhorm's room(Every NPC won't be replaced)

Release note:
You can see enemy clearly in Wolnir 's Room
King of Storm won't be in this Randomizer because it cannot be killed
Soul of Cinder and Double Demons can show their second phase

How install:
1.Open ModEngine , copy "dinput8.dll" and "modengine.ini" to \DARK SOULS III\Game
2.Create a new folder and name it "mod" in \DARK SOULS III\Game
3.Run "pooremma"(you must run it in "Randomizer"),it will create a folder named "map"
4.Copy "map" "event" "script" "sfx" "Data0.bdt" to mod(the folder in step 2) and ENJOY THE GAME


To uninstall,delete mod folder and ModEngine.This ModEngine can works like the old version
You can use it run other mods 

To make sure DarkSouls3 won't crash,you must use the ModEngine which I give you

Thanks:
JKAnderson: Yabber allowed me unpack/repack .bnd files, SoulsFormats that allowed me 
read .msb files and .emevd files
katalash:give me a new version ModEngine to avoid crashes
HotPocketRemix: EventScriptTool help me read and write .emevd files
Jacks0n:work with me all along
Akatosh:help me test this Randomizer and screenshots
那须桃子:the author of the Randomizer's cover